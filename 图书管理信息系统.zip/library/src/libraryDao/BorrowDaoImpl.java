package libraryDao;

import java.sql.Connection;
import java.util.List;
import libraryModel.Borrow;

public class BorrowDaoImpl extends BaseDao<Borrow> implements BorrowDao {

	@Override
	public int deleteBorrowById(int id) {
		String sql = "DELETE FROM `borrow` WHERE `id`=?;";
		return super.update(sql, id);
	}

	@Override
	public List<Borrow> getBorrow(int sid, int aid) {
		String sql = "SELECT * FROM `borrow` WHERE 1=1";
		if(sid!=0){
			sql=sql+" AND `Sid`="+sid;
		}
		if(aid!=0){
			sql=sql+" AND `Aid`="+aid;
		}
		return super.getList(sql);
	}

	public int update(Connection conn,String sql,Object... args){
		return super.update(conn, sql, args);
	}
}
