package libraryDao;

import libraryModel.Student;

public interface StudentDao {
	public int save(Student student);
	public Student get(int sid);
	public Student get(String account);
}
