package libraryDao;

public class FactoryDao {
	public static BookDao getBookDao() {
		return new BookDaoImpl();
	}

	public static AdminDao getAdminDao() {
		return new AdminDaoImpl();
	}

	public static StudentDao getStudentDao() {
		return new StudentDaoImpl();
	}
	public static BorrowDao getBorrowDao() {
		return new BorrowDaoImpl();
	}
}
