package libraryDao;

import libraryModel.Admin;

public interface AdminDao {
	public int save(Admin admin);
	public Admin get(int aid);
	public Admin get(String account);
}
