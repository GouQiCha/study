package libraryDao;

import libraryModel.Student;

public class StudentDaoImpl extends BaseDao<Student> implements StudentDao {

	@Override
	public int save(Student student) {
		String sql = "INSERT INTO `student`(`Sname`,`account`,`password`) VALUES(?,?,?);";
		return super.update(sql, student.getSname(), student.getAccount(),
				student.getPassword());
	}

	@Override
	public Student get(int sid) {
		String sql = "SELECT * FROM `student` WHERE `Sid`=?;";
		return super.get(sql, sid);
	}

	@Override
	public Student get(String account) {
		String sql = "SELECT * FROM `student` WHERE `account`=?;";
		return super.get(sql, account);
	}

}
