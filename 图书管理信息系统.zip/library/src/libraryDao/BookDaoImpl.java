package libraryDao;

import java.util.List;

import libraryModel.Book;


public class BookDaoImpl extends BaseDao<Book> implements BookDao {

	@Override
	public int save(Book book) {
		String sql = "INSERT INTO `book` VALUES(?,?,?,?,?,?,?,?);";
		return super.update(sql, book.getIsbn(), book.getBname(),
				book.getAuthor(), book.getPress(), book.getPublish_date(),
				book.getPrice(), book.getCategory(), book.getState());
	}

	@Override
	public int deleteBookByIsbn(String isbn) {
		String sql = "DELETE FROM `book` WHERE `ISBN`=?;";
		return super.update(sql, isbn);
	}

	@Override
	public int updateBookByIsbn(Book book) {
		String sql = "UPDATE `book` SET `Bname`=?,`author`=?,`press`=?,`publish_date`=?,`price`=?,`category`=?,`state`=? WHERE `ISBN`=?;";
		return super.update(sql, book.getBname(), book.getAuthor(),
				book.getPress(), book.getPublish_date(), book.getPrice(),
				book.getCategory(), book.getState(), book.getIsbn());
	}

	@Override
	public Book get(String isbn) {
		// TODO Auto-generated method stub
		String sql = "SELECT * FROM `book` WHERE `ISBN`=?;";
		return super.get(sql, isbn);
	}

	@Override
	public List<Book> getListAll() {
		String sql = "SELECT * FROM `book`;";
		return super.getList(sql);
	}

	@Override
	public long getCountByName(String bname) {
		String sql = "SELECT COUNT(`ISBN`) FROM `book` WHERE `Bname`=?;";
		return (Long) super.getValue(sql, bname);
	}

	@Override
	public List<Book> query(String isbn, String bname, String author,
			String press) {	/*����sqlע�����*/
		String sql = "SELECT * FROM `book` WHERE 1=1";
		if(isbn!=null && !isbn.equals("")){
			sql=sql+" AND ISBN LIKE '%"+isbn+"%'";
		}
		if(bname!=null && !bname.equals("")){
			sql=sql+" AND bname LIKE '%"+bname+"%'";
		}
		if(author!=null && !author.equals("")){
			sql=sql+" AND author LIKE '%"+author+"%'";
		}
		if(press!=null && !press.equals("")){
			sql=sql+" AND press LIKE '%"+press+"%'";
		}
		return super.getList(sql);
	}

}
