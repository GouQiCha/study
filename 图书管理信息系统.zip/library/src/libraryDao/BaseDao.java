package libraryDao;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.Connection;
import java.util.List;

import libraryUtils.JdbcUtils;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;


public class BaseDao<T> {
	QueryRunner queryRunner = new QueryRunner();
	private Class<T> clazz;
	public BaseDao(){
		Type superType = this.getClass().getGenericSuperclass();
		if(superType instanceof ParameterizedType){
			ParameterizedType pt = (ParameterizedType) superType;
			Type[] tarry = pt.getActualTypeArguments();
			if(tarry[0] instanceof Class){
				clazz = (Class<T>) tarry[0];
			}
		}
	}
	/**
	 * ��ѯ���ݱ���ȡ��sql���Ľ�����ĵ�һ�����ݣ���װ��һ����Ķ��󷵻أ���֧������
	 * �õ�dbUtils������
	 * @param sql
	 * @param args
	 * @return
	 */
	public T get(String sql,Object... args){
		Connection conn=null;
		T entity=null;
		try{
			conn=JdbcUtils.getConnection();
			entity=queryRunner.query(conn, sql, new BeanHandler<T>(clazz), args);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JdbcUtils.closeConn(conn);
		}
		return entity;
	}
	
	public List<T> getList(String sql,Object... args){
		Connection conn=null;
		List<T> list = null;
		try{
			conn=JdbcUtils.getConnection();
			list=queryRunner.query(conn, sql, new BeanListHandler<T>(clazz), args);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JdbcUtils.closeConn(conn);
		}
		return list;
	}
	/**
	 * ����ɾͨ��
	 * @param sql
	 * @param args
	 * @return
	 */
	public int update(String sql,Object... args){
		Connection conn=null;
		int rows=0;
		try{
			conn=JdbcUtils.getConnection();
			rows=queryRunner.update(conn, sql, args);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JdbcUtils.closeConn(conn);
		}
		return rows;
	}
	/**
	 * ֧������
	 * @param sql
	 * @param args
	 * @return
	 */
	public int update(Connection conn,String sql,Object... args){
		int rows=0;
		try{
			rows=queryRunner.update(conn, sql, args);
		}catch(Exception e){
			e.printStackTrace();
		}
		return rows;
	}
	/**
	 * ͨ�õ�sql��䷵�ؽ��ֻ��һ��ֵ�Ĳ�ѯ����
	 * @param sql
	 * @param args
	 * @return
	 */
	public Object getValue(String sql,Object... args){
		Connection conn=null;
		Object obj=null;
		try{
			conn=JdbcUtils.getConnection();
			obj=queryRunner.query(conn, sql, new ScalarHandler(), args);
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			JdbcUtils.closeConn(conn);
		}
		return obj;
	}
}
