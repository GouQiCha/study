package libraryDao;

import java.util.List;

import libraryModel.Book;

public interface BookDao {
	public int save(Book book);
	public int deleteBookByIsbn(String isbn);
	public int updateBookByIsbn(Book book);
	public Book get(String isbn);
	public List<Book> getListAll();
	public long getCountByName(String bname);
	public List<Book> query(String isbn, String bname, String author,
			String press);
}
