package libraryDao;

import java.sql.Connection;
import java.util.List;

import libraryModel.Book;
import libraryModel.Borrow;

public interface BorrowDao {
	public List<Borrow> getBorrow(int sid, int aid);
	public int deleteBorrowById(int id);
	public int update(Connection conn,String sql,Object... args);
}
