package libraryDao;

import libraryModel.Admin;

public class AdminDaoImpl extends BaseDao<Admin> implements AdminDao {

	@Override
	public int save(Admin admin) {
		String sql = "INSERT INTO `admin`(`Aname`,`account`,`password`) VALUES(?,?,?);";
		return super.update(sql, admin.getAname(),admin.getAccount(),admin.getPassword());
	}

	@Override
	public Admin get(int aid) {
		String sql = "SELECT * FROM `admin` WHERE `Aid`=?;";
		return super.get(sql, aid);
	}

	@Override
	public Admin get(String account) {
		String sql = "SELECT * FROM `admin` WHERE `account`=?;";
		return super.get(sql, account);
	}

}
