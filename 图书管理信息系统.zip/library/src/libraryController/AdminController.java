package libraryController;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import libraryModel.Admin;
import libraryService.AdminService;
import libraryService.FactoryService;

public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AdminService adminService = FactoryService.getAdminService();

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("gbk");
		resp.setCharacterEncoding("gbk");
		String fun = req.getServletPath();
		fun = fun.substring(1);
		fun = fun.substring(0, fun.length() - 4);
		try {
			Method method = this.getClass().getDeclaredMethod(fun,
					HttpServletRequest.class, HttpServletResponse.class);
			method.invoke(this, req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void signup(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		if(adminService.get(req.getParameter("account"))==null){
			Admin admin = new Admin();
			admin.setAname(req.getParameter("aname"));
			admin.setAccount(req.getParameter("account"));
			admin.setPassword(req.getParameter("password"));
			int rows = adminService.save(admin);
			if (rows > 0) {
				resp.sendRedirect("admin.jsp");
			} else {
				resp.sendRedirect("error.jsp");
			}
		}else{
			req.setAttribute("note", "���˺��ѱ�ռ��");
			req.getRequestDispatcher("adminSignup.jsp").forward(req, resp);
		}
	}

	private void login(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		HttpSession session = req.getSession();
		String account = req.getParameter("account");
		Admin admin = adminService.get(account);
		if (admin.getPassword().equals(req.getParameter("password"))) {
			session.setAttribute("admin", admin);
			session.setAttribute("authority", "admin");
			resp.sendRedirect("show.bdo");
		} else {
			resp.sendRedirect("admin.jsp");
		}
	}
}
