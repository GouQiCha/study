package libraryController;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import libraryModel.Admin;
import libraryModel.Book;
import libraryModel.Borrow;
import libraryModel.Student;
import libraryService.BookService;
import libraryService.FactoryService;
import libraryService.BorrowService;

public class BorrowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BookService bookService = FactoryService.getBookService();
	BorrowService borrowService = FactoryService.getBorrowService();

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("gbk");
		resp.setCharacterEncoding("gbk");
		String fun = req.getServletPath();
		fun = fun.substring(1);
		fun = fun.substring(0, fun.length() - 4);
		try {
			Method method = this.getClass().getDeclaredMethod(fun,
					HttpServletRequest.class, HttpServletResponse.class);
			method.invoke(this, req, resp);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void borrowdo(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		HttpSession session = req.getSession();
		Borrow borrow = new Borrow();
		String isbn = req.getParameter("isbn");
		int uid = Integer.parseInt(req.getParameter("uid"));
		int day = Integer.parseInt(req.getParameter("day"));
		Date borrow_date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, day);
		Date return_date = null;
		try {
			return_date = sdf.parse(sdf.format(c.getTime()));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		borrow.setIsbn(isbn);
		borrow.setBorrow_date(borrow_date);
		borrow.setReturn_date(return_date);
		Book book = bookService.get(isbn);
		book.setState("0");
		if(session.getAttribute("authority").toString().equals("student")){
			borrow.setSid(uid);
			int i = borrowService.saveTransation(book,borrow);
			if (i==2) {
				resp.sendRedirect("show.bdo");
			} else {
				resp.sendRedirect("error.jsp");
			}
		}else{
			borrow.setAid(uid);
			int i = borrowService.saveTransation(book,borrow);
			if (i==2) {
				resp.sendRedirect("show.bdo");
			} else {
				resp.sendRedirect("error.jsp");
			}
		}
	}
	private void returnn(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		HttpSession session = req.getSession();
		if(session.getAttribute("authority").toString().equals("student")){
			Student student = (Student)session.getAttribute("student");
			int sid = student.getSid();
			List<Borrow> list = borrowService.getBorrow(sid, 0);
			req.setAttribute("borrowList",list);
		}else{
			Admin admin = (Admin)session.getAttribute("admin");
			int aid = admin.getAid();
			List<Borrow> list = borrowService.getBorrow(0, aid);
			req.setAttribute("borrowList",list);
		}
		req.getRequestDispatcher("returnn.jsp").forward(req, resp);
	}
	private void returndo(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		String isbn = req.getParameter("isbn");
		int rowsi = borrowService.deleteBorrowById(id);
		Book book = bookService.get(isbn);
		book.setState("1");
		int rowsj = bookService.updateBookByIsbn(book);
		if (rowsi>0&&rowsj>0) {
			resp.sendRedirect("returnn.wdo");
		} else {
			resp.sendRedirect("error.jsp");
		}
	}
}