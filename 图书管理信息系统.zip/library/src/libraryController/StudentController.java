package libraryController;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import libraryModel.Student;
import libraryService.FactoryService;
import libraryService.StudentService;

public class StudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	StudentService studentService = FactoryService.getStudentService();

	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("gbk");
		resp.setCharacterEncoding("gbk");
		String fun = req.getServletPath();
		fun = fun.substring(1);
		fun = fun.substring(0, fun.length() - 4);
		try {
			Method method = this.getClass().getDeclaredMethod(fun,
					HttpServletRequest.class, HttpServletResponse.class);
			method.invoke(this, req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void signup(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		if (studentService.get(req.getParameter("account")) == null) {
			Student student = new Student();
			student.setSname(req.getParameter("sname"));
			student.setAccount(req.getParameter("account"));
			student.setPassword(req.getParameter("password"));
			int rows = studentService.save(student);
			if (rows > 0) {
				resp.sendRedirect("student.jsp");
			} else {
				resp.sendRedirect("error.jsp");
			}
		} else {
			req.setAttribute("note", "���˺��ѱ�ռ��");
			req.getRequestDispatcher("studentSignup.jsp").forward(req, resp);
		}
	}

	private void login(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		HttpSession session = req.getSession();
		String account = req.getParameter("account");
		Student student = studentService.get(account);
		if (student.getPassword().equals(req.getParameter("password"))) {
			session.setAttribute("student", student);
			session.setAttribute("authority", "student");
			resp.sendRedirect("show.bdo");
		} else {
			resp.sendRedirect("student.jsp");
		}
	}
}
