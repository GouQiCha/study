package libraryController;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import libraryModel.Book;
import libraryService.BookService;
import libraryService.FactoryService;

public class BookController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	BookService bookService = FactoryService.getBookService();

	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		req.setCharacterEncoding("gbk");
		resp.setCharacterEncoding("gbk");
		String fun = req.getServletPath();
		fun = fun.substring(1);
		fun = fun.substring(0, fun.length() - 4);
		try {
			Method method = this.getClass().getDeclaredMethod(fun,
					HttpServletRequest.class, HttpServletResponse.class);
			method.invoke(this, req, resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void add(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		Book book = new Book();
		book.setIsbn(req.getParameter("isbn"));
		book.setBname(req.getParameter("bname"));
		book.setAuthor(req.getParameter("author"));
		book.setPress(req.getParameter("press"));
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String str = req.getParameter("publish_date");
		Date date = null;
		try {
			date = formatter.parse(str);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		book.setPublish_date(date);
		double price = Double.parseDouble(req.getParameter("price"));
		book.setPrice(price);
		book.setCategory(req.getParameter("category"));
		book.setState("1");
		int rows = bookService.save(book);
		if (rows > 0) {
			resp.sendRedirect("show.bdo");
		} else {
			resp.sendRedirect("error.jsp");
		}
	}

	private void delete(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String isbn = req.getParameter("isbn");
		int rows = bookService.deleteBookByIsbn(isbn);
		if (rows > 0) {
			resp.sendRedirect("show.bdo");
		} else {
			resp.sendRedirect("error.jsp");
		}
	}

	private void update(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String isbn = req.getParameter("isbn");
		Book book = bookService.get(isbn);
		req.setAttribute("book", book);
		req.getRequestDispatcher("update.jsp").forward(req, resp);
	}

	private void query(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		HttpSession session = req.getSession();
		String isbn = req.getParameter("isbn");
		String bname = req.getParameter("bname");
		String author = req.getParameter("author");
		String press = req.getParameter("press");
		isbn = isbn
				.replaceAll(
						"[`~!@#$^&*()=|{}':;',\\[\\].<>/?~!@#������&*����&mdash;-|{}������������������������]",
						"");
		bname = bname
				.replaceAll(
						"[`~!@#$^&*()=|{}':;',\\[\\].<>/?~!@#������&*����&mdash;-|{}������������������������]",
						"");
		author = author
				.replaceAll(
						"[`~!@#$^&*()=|{}':;',\\[\\].<>/?~!@#������&*����&mdash;-|{}������������������������]",
						"");
		press = press
				.replaceAll(
						"[`~!@#$^&*()=|{}':;',\\[\\].<>/?~!@#������&*����&mdash;-|{}������������������������]",
						"");
		List<Book> list = bookService.query(isbn, bname, author, press);
		req.setAttribute("bookList", list);
		if(session.getAttribute("authority").toString().equals("student")){
			req.getRequestDispatcher("search.jsp").forward(req, resp);
		}else{
			req.getRequestDispatcher("searcha.jsp").forward(req, resp);
		}
	}

	private void updatedo(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String isbn = req.getParameter("isbn");
		Book book = bookService.get(isbn);
		book.setBname(req.getParameter("bname"));
		book.setAuthor(req.getParameter("author"));
		book.setPress(req.getParameter("press"));
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String str = req.getParameter("publish_date");
		Date date = null;
		try {
			date = formatter.parse(str);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		book.setPublish_date(date);
		double price = Double.parseDouble(req.getParameter("price"));
		book.setPrice(price);
		book.setCategory(req.getParameter("category"));
		int rows = bookService.updateBookByIsbn(book);
		if (rows > 0) {
			resp.sendRedirect("show.bdo");
		} else {
			resp.sendRedirect("error.jsp");
		}
	}
	
	private void show(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		HttpSession session = req.getSession();
		List<Book> list = bookService.query(null, null, null, null);
		ArrayList newlist = new ArrayList();
		if (list != null && list.size() > 0) {
			for (Book book : list) {
				if(book.getState()!=null&&book.getState().equals("1")){
					newlist.add(book);
				}
			}
		}
		req.setAttribute("bookList",newlist);
		if(session.getAttribute("authority").toString().equals("student")){
			req.getRequestDispatcher("book.jsp").forward(req, resp);
		}else{
			req.getRequestDispatcher("booka.jsp").forward(req, resp);
		}
	}

	private void borrow(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String isbn = req.getParameter("isbn");
		Book book = bookService.get(isbn);
		req.setAttribute("book", book);
		req.getRequestDispatcher("borrow.jsp").forward(req, resp);
	}
	private void sort(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		HttpSession session = req.getSession();
		String method = req.getParameter("method");
		List<Book> list = bookService.query(null, null, null, null);
		ArrayList newlist = new ArrayList();
		if (list != null && list.size() > 0) {
			for (Book book : list) {
				if(book.getState()!=null&&book.getState().equals("1")){
					newlist.add(book);
				}
			}
		}
		if(method.equals("isbn")){
			Collections.sort(newlist, new Comparator<Book>() {
	            @Override
	            public int compare(Book book1, Book book2) {
	                return (book2.getIsbn()).compareTo(book1.getIsbn());
	            }
	        });
		}else if(method.equals("name")){
			Collections.sort(newlist, new Comparator<Book>() {
	            @Override
	            public int compare(Book book1, Book book2) {
	                return (book2.getBname()).compareTo(book1.getBname());
	            }
	        });
		}else if(method.equals("author")){
			Collections.sort(newlist, new Comparator<Book>() {
	            @Override
	            public int compare(Book book1, Book book2) {
	                return (book2.getAuthor()).compareTo(book1.getAuthor());
	            }
	        });
		}else if(method.equals("date")){
			Collections.sort(newlist, new Comparator<Book>() {
	            @Override
	            public int compare(Book book1, Book book2) {
	                return (book2.getPublish_date()).compareTo(book1.getPublish_date());
	            }
	        });
		}
		req.setAttribute("bookList",newlist);
		if(session.getAttribute("authority").toString().equals("student")){
			req.getRequestDispatcher("book.jsp").forward(req, resp);
		}else{
			req.getRequestDispatcher("booka.jsp").forward(req, resp);
		}
	}
}
