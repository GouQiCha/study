package libraryService;

import java.sql.Connection;

import libraryDao.AdminDao;
import libraryDao.FactoryDao;
import libraryModel.Admin;
import libraryUtils.JdbcUtils;

public class AdminServiceImpl implements AdminService {
	AdminDao adminDao = FactoryDao.getAdminDao();
	@Override
	public int save(Admin admin) {
		// TODO Auto-generated method stub
		return adminDao.save(admin);
	}

	@Override
	public Admin get(int aid) {
		// TODO Auto-generated method stub
		return adminDao.get(aid);
	}

	@Override
	public Admin get(String account) {
		// TODO Auto-generated method stub
		return adminDao.get(account);
	}
}
