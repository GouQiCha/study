package libraryService;

import java.sql.Connection;
import java.util.List;

import libraryDao.BookDao;
import libraryDao.FactoryDao;
import libraryModel.Book;
import libraryUtils.JdbcUtils;


public class BookServiceImpl implements BookService {
	BookDao bookDao = FactoryDao.getBookDao();
	@Override
	public int save(Book book) {
		// TODO Auto-generated method stub
		return bookDao.save(book);
	}

	@Override
	public int deleteBookByIsbn(String isbn) {
		return bookDao.deleteBookByIsbn(isbn);
	}

	@Override
	public int updateBookByIsbn(Book book) {
		// TODO Auto-generated method stub
		return bookDao.updateBookByIsbn(book);
	}

	@Override
	public Book get(String isbn) {
		// TODO Auto-generated method stub
		return bookDao.get(isbn);
	}

	@Override
	public List<Book> getListAll() {
		// TODO Auto-generated method stub
		return bookDao.getListAll();
	}

	@Override
	public long getCountByName(String bname) {
		// TODO Auto-generated method stub
		return bookDao.getCountByName(bname);
	}

	@Override
	public List<Book> query(String isbn, String bname, String author,
			String press) {
		return bookDao.query(isbn,bname,author,press);
	}

}
