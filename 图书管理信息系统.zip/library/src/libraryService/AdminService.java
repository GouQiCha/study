package libraryService;

import libraryModel.Admin;

public interface AdminService {
	public int save(Admin admin);
	public Admin get(int aid);
	public Admin get(String account);
}
