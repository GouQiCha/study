package libraryService;

import libraryModel.Student;

public interface StudentService {
	public int save(Student student);
	public Student get(int sid);
	public Student get(String account);
}
