package libraryService;

import java.util.List;

import libraryModel.Book;
import libraryModel.Borrow;

public interface BorrowService {
	public List<Borrow> getBorrow(int sid, int aid);
	public int deleteBorrowById(int id);
	public int saveTransation(Book book, Borrow borrow);
}
