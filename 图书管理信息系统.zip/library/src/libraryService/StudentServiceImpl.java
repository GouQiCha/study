package libraryService;

import java.sql.Connection;

import libraryDao.FactoryDao;
import libraryDao.StudentDao;
import libraryModel.Student;
import libraryUtils.JdbcUtils;

public class StudentServiceImpl implements StudentService {
	StudentDao studentDao = FactoryDao.getStudentDao();
	@Override
	public int save(Student student) {
		// TODO Auto-generated method stub
		return studentDao.save(student);
	}

	@Override
	public Student get(int sid) {
		// TODO Auto-generated method stub
		return studentDao.get(sid);
	}

	@Override
	public Student get(String account) {
		// TODO Auto-generated method stub
		return studentDao.get(account);
	}

}
