package libraryService;

import java.sql.Connection;
import java.util.List;

import libraryDao.BorrowDao;
import libraryDao.FactoryDao;
import libraryModel.Book;
import libraryModel.Borrow;
import libraryUtils.JdbcUtils;

public class BorrowServiceImpl implements BorrowService {
	BorrowDao borrowDao = FactoryDao.getBorrowDao();

	@Override
	public List<Borrow> getBorrow(int sid,int aid) {
		// TODO Auto-generated method stub
		return borrowDao.getBorrow(sid,aid);
	}

	@Override
	public int deleteBorrowById(int id) {
		// TODO Auto-generated method stub
		return borrowDao.deleteBorrowById(id);
	}

	@Override
	public int saveTransation(Book book, Borrow borrow) {
		Connection conn = null;
		int i = 0;
		try{
			conn=JdbcUtils.getConnection();
			conn.setAutoCommit(false);//��ʼ����
			String sql1 = "UPDATE `book` SET `state`=? WHERE `ISBN`=?;";
			i+= borrowDao.update(conn, sql1, book.getState(),book.getIsbn());
			if(borrow.getSid()!=0){
				String sql2 = "INSERT INTO `borrow`(`ISBN`,`Sid`,`borrow_date`,`return_date`) VALUES(?,?,?,?);";
				i+= borrowDao.update(conn, sql2, borrow.getIsbn(), borrow.getSid(),
						borrow.getBorrow_date(), borrow.getReturn_date());
			}else{
				String sql2 = "INSERT INTO `borrow`(`ISBN`,`Aid`,`borrow_date`,`return_date`) VALUES(?,?,?,?);";
				i+= borrowDao.update(conn, sql2, borrow.getIsbn(), borrow.getAid(),
						borrow.getBorrow_date(), borrow.getReturn_date());
			}
			conn.commit();
		}catch(Exception e){
			JdbcUtils.rollbackTransation(conn);//�ع�����
		}
		return i;
	}

}
