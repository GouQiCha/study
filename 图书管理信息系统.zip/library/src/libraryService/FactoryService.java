package libraryService;

public class FactoryService {
	public static BookService getBookService(){
		return new BookServiceImpl();
	}
	public static AdminService getAdminService(){
		return new AdminServiceImpl();
	}
	public static StudentService getStudentService(){
		return new StudentServiceImpl();
	}
	public static BorrowService getBorrowService(){
		return new BorrowServiceImpl();
	}
}
