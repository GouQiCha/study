package libraryModel;

import java.util.Date;

public class Borrow {
	private int id;
	private String isbn;
	private int sid;
	private int aid;
	private Date borrow_date;
	private Date return_date;

	public Borrow() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Borrow(int id, String isbn, int sid, int aid, Date borrow_date,
			Date return_date) {
		super();
		this.id = id;
		this.isbn = isbn;
		this.sid = sid;
		this.aid = aid;
		this.borrow_date = borrow_date;
		this.return_date = return_date;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

	public int getAid() {
		return aid;
	}

	public void setAid(int aid) {
		this.aid = aid;
	}

	public Date getBorrow_date() {
		return borrow_date;
	}

	public void setBorrow_date(Date borrow_date) {
		this.borrow_date = borrow_date;
	}

	public Date getReturn_date() {
		return return_date;
	}

	public void setReturn_date(Date return_date) {
		this.return_date = return_date;
	}

	@Override
	public String toString() {
		return "Borrow [id=" + id + ", isbn=" + isbn + ", sid=" + sid
				+ ", aid=" + aid + ", borrow_date=" + borrow_date
				+ ", return_date=" + return_date + "]";
	}

}
