package libraryModel;

import java.util.Date;

public class Book {
	private String isbn;
	private String bname;
	private String author;
	private String press;
	private Date publish_date;
	private double price;
	private String category;
	private String state;

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getPress() {
		return press;
	}

	public void setPress(String press) {
		this.press = press;
	}

	public Date getPublish_date() {
		return publish_date;
	}

	public void setPublish_date(Date publish_date) {
		this.publish_date = publish_date;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Book(String isbn, String bname, String author, String press,
			Date publish_date, double price, String category, String state) {
		super();
		this.isbn = isbn;
		this.bname = bname;
		this.author = author;
		this.press = press;
		this.publish_date = publish_date;
		this.price = price;
		this.category = category;
		this.state = state;
	}

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", bname=" + bname + ", author=" + author
				+ ", press=" + press + ", publish_date=" + publish_date
				+ ", price=" + price + ", category=" + category + ", state="
				+ state + "]";
	}

}
