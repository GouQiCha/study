package libraryTest;

import static org.junit.Assert.*;
import libraryDao.AdminDao;
import libraryDao.AdminDaoImpl;
import libraryModel.Admin;

import org.junit.Test;

public class AdminDaoImplTest {
	AdminDao adminDao = new AdminDaoImpl();
	@Test
	public void testGetString() {
		Admin admin = adminDao.get(1);
		System.out.println(admin);
	}

}
