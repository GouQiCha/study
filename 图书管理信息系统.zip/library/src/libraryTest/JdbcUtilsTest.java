package libraryTest;

import static org.junit.Assert.*;

import java.sql.Connection;

import libraryUtils.JdbcUtils;

import org.junit.Test;

public class JdbcUtilsTest {

	@Test
	public void testGetConnection() {
		Connection conn = JdbcUtils.getConnection();
		System.out.println(conn);
	}
}
