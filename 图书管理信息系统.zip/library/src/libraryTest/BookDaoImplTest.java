package libraryTest;

import static org.junit.Assert.*;
import libraryDao.BookDao;
import libraryDao.BookDaoImpl;
import libraryModel.Book;

import org.junit.Test;

public class BookDaoImplTest {

	BookDao bookDao=new BookDaoImpl();
	@Test
	public void testGetString() {
		Book book = bookDao.get("1");
		System.out.println(book);
	}

}
